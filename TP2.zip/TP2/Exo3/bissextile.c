#include <stdio.h>

int main() {
	unsigned int annee = 0;
	//Demander � l'utilisateur d'entrer une valeur
	printf("Entrez l'annee:\n");
	scanf("%u", &annee);
	//V�rifier que la valeur entr�e est valide 
	while (annee > 10000) {
		printf("La valeur entree n'est pas valide \nEntrez l'annee:\n");
		scanf("%u", &annee);
	}
	//V�rifier si l'ann�e entr�e est bissextile
	//Avec une seule expression logique
	if ((annee % 4 == 0) && ((annee % 100 != 0) || (annee % 400 == 0))) {
		printf("methode 1: L'annee %u est bissextile\n", annee);
	}
	else {
		printf("methode 1: L'annee %u n'est pas bissextile\n", annee);
	}
	//Avec les conditions imbriqu�es
	if (annee % 4 == 0) {
		if (annee % 100 != 0) {
			printf("methode 2: L'annee %u est bissextile\n", annee);
		}
		else {
			if (annee % 400 == 0) {
				printf("methode 2: L'annee %u est bissextile\n", annee);
			}
			else {
				printf("methode 2: L'annee %u n'est pas bissextile\n", annee);
			}
		}
	}
	else {
		printf("methode 2: L'annee %u n'est pas bissextile\n", annee);
	}
}

