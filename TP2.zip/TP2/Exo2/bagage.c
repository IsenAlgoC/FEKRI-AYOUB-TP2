#include <stdio.h>
#include <stdlib.h> 
#include <string.h>

void est_valide(float longueur, float largeur, float hauteur){
	// Par convention on a longueur >= largeur >= hauteur
	float tmp;
	if (longueur < largeur) {
		tmp = longueur;
		longueur = largeur;
		largeur = tmp;
	}
	if (longueur < hauteur) {
		tmp = longueur;
		longueur = hauteur;
		hauteur = tmp;
	}
	if (largeur < hauteur) {
		tmp = largeur;
		largeur = hauteur;
		hauteur = tmp;
	}
	if (longueur <= 55 && largeur <= 35 && hauteur <= 25) {
		printf("bagage VALIDE\n");
	}
	else {
		printf("bagage NON VALIDE\n");
	}
}

void main() {
	//Declaration et initialisation des variables
	float longueur = 0.0;
	float largeur = 0.0;
	float hauteur = 0.0;
	char* reponse = "oui";
	while (strcmp(reponse, "oui") == 0){
		//Demander les dimensions du bagage
		printf("Quelle est la longueur de votre bagage en cm?\n");
		scanf("%f", &longueur);
		//V�rifier que la longueur est entre 1 et 150
		while (longueur < 1 || longueur > 150) {
			printf("La longueur saisit n'est pas vaide \nQuelle est la longueur de votre bagage en cm?\n");
			scanf("%f", &longueur);
		}
		printf("Quelle est la hauteur de votre bagage en cm?\n");
		scanf("%f", &hauteur);
		//V�rifier que la hauteur est entre 1 et 150
		while (hauteur < 1 || hauteur > 150) {
			printf("La hauteur saisit n'est pas vaide \nQuelle est la hauteur de votre bagage en cm?\n");
			scanf("%f", &hauteur);
		}
		printf("Quelle est la largeur de votre bagage en cm?\n");
		scanf("%f", &largeur);
		//V�rifier que la largeur est entre 1 et 150
		while (largeur < 1 || largeur > 150) {
			printf("La largeur saisit n'est pas vaide \nQuelle est la largeur de votre bagage en cm?\n");
			scanf("%f", &largeur);
		}
		//v�rifier si le bagage est valide � l'aide de la fonction auxiliaire est_valide 
		est_valide(longueur, largeur, hauteur);
		//Demander si l'utilisateur souhaite enregistrer un autre bagage
		printf("Souhaitez-vous enregistrer un autre bagage (oui/non)?\n");
		scanf("%s", reponse);
	}
}