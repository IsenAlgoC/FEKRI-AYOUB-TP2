#include <stdio.h>

int main(){
	/*	
	*  Un programme qu calcule la somme des n premiers entiers naturels
	* 0 est concid�r� le premier entier positif, donc la somme par exemple
	* des 10 premiers entiers est 0 + 1 + .... + 9
	* la valeur maximum pour n sans d�pacement de capacit� est 362
	*/
	unsigned short int max_somme = -1;
	unsigned short int n_for;
	/*
	* Un programme qui demande � l'utilisateur de saisir la valeur de n valide
	*/
	printf("Entrez une valeur pour n:\n");
	scanf("%hu", &n_for);
	while (n_for > 362) {
		printf("La valeur entr�e n'est pas valide !! \nEntrez une valeur pour n:\n");
		scanf("%hu", &n_for);
	}
	unsigned short int somme_for = 0;
	for (unsigned short int i = 0; i < n_for; i++) {
		somme_for += i;
	}
	printf("La somme des %d premiers entiers positifs est: %d\n", n_for , somme_for);
	/*
	* Un programme qui permet une sortie anticip�e si on d�pace la capacit�
	*/
	unsigned short int somme_while = 0;
	unsigned short int n_while = 100;
	unsigned short int val = 0;
	while (max_somme - somme_while >= val && val < n_while) {
		somme_while += val;
		val++;
	}
	printf("boucle while: La somme des %d premiers entiers positifs est: %d\n", n_while, somme_while);
}