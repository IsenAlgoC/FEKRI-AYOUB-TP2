#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main() {
	int tentatives = 1;
	//G�n�ration du nombre al�atoire
	srand( time(NULL) );
	int nombre = rand();
	//Demander au joueur de deviner
	int devine = 0;
	printf("!!!!!!!!!!! Devinez le nombre !!!!!!!!!!!!\n");
	scanf("%d", &devine);
	//Traiter sa r�ponse
	while (devine != nombre && tentatives < 30) {
		if ( devine < nombre ) {
			printf("Trop petit! \nUne autre chance!\n");
			scanf("%d", &devine);
			tentatives++;
		}
		if (devine > nombre) {
			printf("Trop grand! \nUne autre chance!\n");
			scanf("%d", &devine);
			tentatives++;
		}
	}
	if (devine == nombre) {
		printf("********** BRAVO: Vous avez trouve le bon nombre en %d tentatives ************\n", tentatives);
	}
	else {
		printf("Pas de bol! Vous avez d�pass� le nombre de tentatives permises: 30. Le nombre �tait: %d\n", nombre);
	}
}